package PedroM_Guerra.controle_aso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControleAsoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControleAsoApplication.class, args);
	}

}
