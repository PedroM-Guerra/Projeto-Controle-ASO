package PedroM_Guerra.controle_aso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleAsoApplicationTests {

	@Test
	void contextLoads() {
	}

}
